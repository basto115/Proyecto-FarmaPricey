from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q, Prefetch, Count
from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_http_methods, require_POST
from django.core.paginator import Paginator
from django.contrib import messages
from django.core.validators import validate_email

import re
import unicodedata
import pytesseract

from django.contrib.auth import update_session_auth_hash
from django.core.exceptions import ValidationError

from PIL import Image, UnidentifiedImageError, ImageOps, ImageFilter
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

from django.http import HttpResponse
from farmacia.models import ImagenProducto  

from django.contrib.auth import (
    authenticate,
    login,
    logout,
    get_user_model,
)
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

from django.contrib.auth.decorators import login_required

from .models import Medicamento, Farmacia, Producto, Precio, Sucursal, Suscripcion
from itertools import combinations

from math import radians, sin, cos, sqrt, atan2

from types import SimpleNamespace

def inicio(request):
    busqueda = request.GET.get("buscar", "").strip()

    categoria_seleccionada = request.GET.get("categoria", "").strip()

    productos = Producto.objects.annotate(
        cantidad_farmacias=Count(
            "precios__farmacia",
            distinct=True
        )
    ).prefetch_related(
        Prefetch(
            "precios",
            queryset=Precio.objects.select_related("farmacia").order_by("precio"),
        ),
        "medicamento",
    ).order_by("-cantidad_farmacias", "nombre")
    
    no_encontrados = []

    if busqueda:
        # Separadores explícitos: coma, punto y coma o salto de línea.
        if any (separador in busqueda for separador in [",", ";", "\n"]):
            terminos = [
                termino.strip()
                for termino in busqueda.replace(";", ",")
                .replace("\n", ",")
                .split(",")
                if termino.strip()
            ]
        else:
            #si intenta buscar el nombre completo
            terminos = [busqueda]
            
            coincidencia_completa = productos.filter(
                Q(nombre__icontains=busqueda)
                | Q(medicamento__nombre__icontains=busqueda)
                | Q(medicamento__principio_activo__icontains=busqueda)
                | Q(presentacion__icontains=busqueda)
                | Q(laboratorio__icontains=busqueda)
                | Q(categoria__icontains=busqueda)
            ).exists()
            
            #si no lo encuentra intenta detectar varios productos 
            
            if not coincidencia_completa:
                nombres = list(
                    Medicamento.objects.exclude(nombre="")
                    .values_list("nombre", flat=True)
                    .distinct()
                )
                
                encontrados = [
                    nombre
                    for nombre in nombres
                    if nombre.lower() in busqueda.lower()
                ]
                
                if len(encontrados) >= 2:
                    terminos = encontrados
                elif encontrados:
                    terminos = encontrados
                elif len(busqueda.split()) >= 2:
                    terminos = busqueda.split()
                
        #busca cualquiera que coincida con el termino
        consulta = Q()
        
        for termino in terminos:
            consulta |= (
                Q(nombre__icontains=termino)
                | Q(medicamento__nombre__icontains=termino)
                | Q(medicamento__principio_activo__icontains=termino)
                | Q(presentacion__icontains=termino)
                | Q(laboratorio__icontains=termino)
                | Q(categoria__icontains=termino)
            )
            
        productos = productos.filter(consulta).distinct()
        
    if categoria_seleccionada:
        productos = productos.filter(categoria=categoria_seleccionada)

    #Dejenlo en 6 o a lo mucho 9, la pagina se alarga demasiado si ponen muchos
    
    paginador = Paginator(productos, 9)
    pagina_obj = paginador.get_page(request.GET.get("pagina"))
    
    rango_paginas = paginador.get_elided_page_range(
        number=pagina_obj.number,
        on_each_side=2,
        on_ends=1
    )

    contexto = {
            "productos": pagina_obj,
            "pagina_obj": pagina_obj,
            "busqueda": busqueda,
            "categoria_seleccionada": categoria_seleccionada,
            "categorias": Producto.objects.exclude(
                categoria__isnull=True)
                .exclude(
                    categoria=""
                ).values_list(
                    "categoria", flat=True
                ).distinct().order_by("categoria"),
            "rango_paginas": rango_paginas
        }
    
    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        return render(
            request,
            "partials/catalogo.html",
            contexto,
        )
    
    return render(
        request,
        "inicio.html",
        contexto,
    )

def detalle_medicamento(request, medicamento_id):
    medicamento = get_object_or_404(
        Medicamento.objects.prefetch_related(
            Prefetch(
                "productos",
                queryset=Producto.objects.prefetch_related(
                    Prefetch(
                        "precios",
                        queryset=Precio.objects.select_related(
                            "farmacia"
                        ).order_by("precio"),
                    )
                ),
            )
        ),
        id=medicamento_id,
    )

    productos_originales = list(medicamento.productos.all())
    
    # Agrupar productos equivalentes.
    grupos_productos = {}
    
    for producto in productos_originales:
        
        clave = normalizar_nombre_producto(producto.nombre)

        if clave not in grupos_productos:
            grupos_productos[clave] = {
                "producto": producto,
                "precios": {}
            }

        # Reunir los precios de todas las versiones.
        for precio in producto.precios.all():
            
            farmacia_id = precio.farmacia_id

            if not farmacia_id:
                continue
            
            precio_actual = grupos_productos[clave]["precios"].get(
                farmacia_id
            )
            
            # Si una farmacia aparece dos veces, conservar el precio más bajo.
            if (
                precio_actual is None
                or precio.precio < precio_actual.precio
            ):
                grupos_productos[clave]["precios"][farmacia_id] = precio
                
    # Construir productos unificados.
    productos = []
    
    for grupo in grupos_productos.values():
        
        producto = grupo["producto"]
        
        precios_unificados = sorted(
            grupo["precios"].values(),
            key=lambda precio: precio.precio
        )

        productos.append(
            SimpleNamespace(
                id=producto.id,
                nombre=producto.nombre,
                presentacion=producto.presentacion,
                medicamento_id=producto.medicamento_id,
                precios=precios_unificados
            )
        )
        
    # El comparador utiliza solamente los productos unificados.
    productos_detalle = productos
        
    #Buscar otras presentaciones con el mismo principio activo
    productos_relacionados = []
        
    if medicamento.principio_activo:
        productos_relacionados = list(
            Producto.objects.filter(
                medicamento__principio_activo__iexact=medicamento.principio_activo
            )
            .exclude(medicamento_id=medicamento.id)
            .select_related("medicamento")
            .order_by("nombre")[:4]
        )
        
    # Esto muestra la comparación de precios solo del producto que estamos viendo
    productos_detalle = productos
    
    # obtener farmacias que tienen precios para tal medicamento
    farmacias_ids = set()
    productos_por_farmacia = {}

    for producto in productos_detalle:
        for precio in producto.precios:
            farmacia_id = precio.farmacia_id
            
            if not farmacia_id:
                continue
            
            farmacias_ids.add(farmacia_id)
            
            productos_por_farmacia.setdefault(farmacia_id, []).append({
                "producto_id": producto.id,
                "producto_nombre": producto.nombre,
                "precio": str(precio.precio),
                "disponible": precio.disponible,
                "url_producto": precio.url_producto,
            })

    # obtener sucursaler aprobadas
    sucursales = Sucursal.objects.select_related(
        "farmacia"
    ).filter(
        aprobada=True,
        farmacia_id__in=farmacias_ids,
        latitud__isnull=False,
        longitud__isnull=False,
    ).order_by("nombre")
    
    farmacias_mapa = [
        {
            "id": sucursal.id,
            "farmacia_id": sucursal.farmacia_id,
            "nombre": sucursal.nombre,
            "direccion": sucursal.direccion,
            "comuna": sucursal.comuna,
            "latitud": float(sucursal.latitud),
            "longitud": float(sucursal.longitud),
            "sitio_web": sucursal.sitio_web,
            "farmacia": (
                sucursal.farmacia.nombre
                if sucursal.farmacia else None
            ),
            "tiene_precios": sucursal.farmacia_id is not None,
            "origen": sucursal.origen,
            "productos": productos_por_farmacia.get(
                sucursal.farmacia_id, []
            ),
        }
        for sucursal in sucursales 
    ]

    return render(
        request,
        "detalle_medicamento.html",
        {
            "medicamento": medicamento,
            "productos_detalle": productos_detalle,
            "productos_relacionados": productos_relacionados,
            "farmacias_mapa": farmacias_mapa,
        },
    )

def detalle_producto(request, producto_id):
    producto = get_object_or_404(
        Producto.objects.prefetch_related(
            Prefetch(
                "precios",
                queryset=Precio.objects.select_related(
                    "farmacia"
                ).order_by("precio"),
            )
        ),
        id=producto_id,
    )

    # Obtener las farmacias que tienen precios para este producto.
    farmacias_ids = set()
    productos_por_farmacia = {}

    for precio in producto.precios.all():
        farmacia_id = precio.farmacia_id

        if not farmacia_id:
            continue
        
        farmacias_ids.add(farmacia_id)
        
        productos_por_farmacia.setdefault(farmacia_id, []).append({
            "producto_id": producto.id,
            "producto_nombre": producto.nombre,
            "precio": str(precio.precio),
            "disponible": precio.disponible,
            "url_producto": precio.url_producto,
        })
        
     # Obtener las sucursales aprobadas con coordenadas.
    sucursales = Sucursal.objects.select_related(
        "farmacia"
    ).filter(
        aprobada=True,
        farmacia_id__in=farmacias_ids,
        latitud__isnull=False,
        longitud__isnull=False,
    ).order_by("nombre")

    farmacias_mapa = [
        {
            "id": sucursal.id,
            "farmacia_id": sucursal.farmacia_id,
            "nombre": sucursal.nombre,
            "direccion": sucursal.direccion,
            "comuna": sucursal.comuna,
            "latitud": float(sucursal.latitud),
            "longitud": float(sucursal.longitud),
            "sitio_web": sucursal.sitio_web,
            "farmacia": (
                sucursal.farmacia.nombre
                if sucursal.farmacia else None
            ),
            "tiene_precios": sucursal.farmacia_id is not None,
            "origen": sucursal.origen,
            "productos": productos_por_farmacia.get(
                sucursal.farmacia_id, []
            ),
        }
        for sucursal in sucursales
    ]
    
    print("FARMACIAS IDS:", farmacias_ids)
    print("TOTAL SUCURSALES:", len(farmacias_mapa))
    print("PRIMERAS SUCURSALES:", farmacias_mapa[:5])
    
    return render(
        request,
        "detalle_medicamento.html",
        {
            "medicamento": producto,
            "productos_detalle": [producto],
            "farmacias_mapa": farmacias_mapa,
            "es_producto_independiente": True,
        },
    )

@require_GET
def listar_farmacias(request):
    sucursales = Sucursal.objects.select_related(
        "farmacia"
    ).filter(
        aprobada=True
    ).order_by("nombre")

    datos = [
        {
            "id": sucursal.id,
            "nombre": sucursal.nombre,
            "direccion": sucursal.direccion,
            "comuna": sucursal.comuna,
            "latitud": (
                float(sucursal.latitud)
                if sucursal.latitud is not None
                else None
            ),
            "longitud": (
                float(sucursal.longitud)
                if sucursal.longitud is not None
                else None
            ),
            "sitio_web": sucursal.sitio_web,
            "farmacia": (
                sucursal.farmacia.nombre
                if sucursal.farmacia
                else None
            ),
            "tiene_precios": sucursal.farmacia_id is not None,
            "origen": sucursal.origen,
        }
        for sucursal in sucursales
        if sucursal.latitud is not None
        and sucursal.longitud is not None
    ]

    return JsonResponse({"farmacias": datos})



@require_GET
def listar_precios(request):
    precios = Precio.objects.select_related(
        "producto", "farmacia", "producto__medicamento"
    ).all().order_by("precio")

    datos = [
        {
            "id": precio.id,
            "producto": precio.producto.nombre,
            "medicamento": (
                precio.producto.medicamento.nombre
                if precio.producto.medicamento else None
            ),
            "categoria": precio.producto.categoria,
            "farmacia": precio.farmacia.nombre,
            "precio": precio.precio,
            "precio_normal": precio.precio_normal,
            "disponible": precio.disponible,
            "fecha_actualizacion": precio.fecha_actualizacion.isoformat(),
            "url_producto": precio.url_producto,
        }
        for precio in precios
    ]
    return JsonResponse(
        {"precios": datos},
        json_dumps_params={"ensure_ascii": False},
    )


@require_GET
def api_medicamentos(request):
    medicamentos = Medicamento.objects.all().values(
        "id", "nombre", "principio_activo"
    )
    return JsonResponse(
        list(medicamentos),
        safe=False,
        json_dumps_params={"ensure_ascii": False},
    )



@require_http_methods(["GET", "POST"])
def vista_registro(request):
    User = get_user_model()

    if request.user.is_authenticated:
        return redirect("inicio")

    nombre_completo = ""
    correo = ""

    if request.method == "POST":
        nombre_completo = request.POST.get("nombre_completo", "").strip()
        correo = request.POST.get("correo", "").strip().lower()
        contrasena = request.POST.get("contrasena", "")
        confirmar = request.POST.get("confirmar-contrasena", "")

        partes_nombre = nombre_completo.split()

        if not nombre_completo or not correo or not contrasena or not confirmar:
            messages.error(request, "Todos los campos son obligatorios.")

        elif len(partes_nombre) < 2:
            messages.error(request, "Ingresa tu nombre y al menos un apellido.")

        elif len(correo) > 150:
            messages.error(
                request,
                "El correo electrónico no puede superar los 150 caracteres."
            )

        else:
            try:
                validate_email(correo)

                if User.objects.filter(email__iexact=correo).exists():
                    messages.error(request, "Ese correo electrónico ya está registrado.")

                elif User.objects.filter(username__iexact=correo).exists():
                    messages.error(request, "Ese correo ya está registrado como usuario.")

                elif contrasena != confirmar:
                    messages.error(request, "Las contraseñas no coinciden.")

                else:
                    usuario = User(
                        username=correo,
                        email=correo,
                        first_name=partes_nombre[0],
                        last_name=" ".join(partes_nombre[1:])
                    )

                    validate_password(contrasena, user=usuario)

                    usuario = User.objects.create_user(
                        username=correo,
                        email=correo,
                        password=contrasena,
                        first_name=partes_nombre[0],
                        last_name=" ".join(partes_nombre[1:])
                    )

                    Suscripcion.objects.create(
                        usuario=usuario,
                        es_premium=False
                    )

                    # Iniciar sesión automáticamente
                    usuario_autenticado = authenticate(
                        request,
                        username=correo,
                        password=contrasena
                    )

                    if usuario_autenticado is not None:
                        login(request, usuario_autenticado)
                        messages.success(
                            request,
                            "¡Tu cuenta fue creada correctamente! Bienvenido/a a FARMA PRICEY."
                        )
                        return redirect("inicio")

                    messages.error(
                        request,
                        "Tu cuenta fue creada, pero no se pudo iniciar sesión automáticamente."
                    )

            except ValidationError as errores:
                for error in errores.messages:
                    messages.error(request, error)

    return render(request, "registro.html", {
        "nombre_completo": nombre_completo,
        "correo": correo
    })


@require_http_methods(["GET", "POST"])
def vista_login(request):

    if request.user.is_authenticated:
        return redirect("inicio")

    correo = ""

    if request.method == "POST":
        correo = request.POST.get("correo", "").strip().lower()
        contrasena = request.POST.get("contrasena", "")

        User = get_user_model()

        usuario = User.objects.filter(
            email__iexact=correo
        ).first()

        if usuario:
            usuario_autenticado = authenticate(
                request,
                username=usuario.username,
                password=contrasena,
            )

            if usuario_autenticado is not None:
                login(request, usuario_autenticado)

                messages.success(
                    request,
                    f"¡Bienvenido/a, {usuario.first_name}!"
                )

                return redirect("inicio")

        messages.error(
            request,
            "Correo electrónico o contraseña incorrectos."
        )

    return render(request, "login.html", {
        "correo": correo,
        "ocultar_notificaciones_globales": True
    })

@require_http_methods(["POST"])
def cerrar_sesion(request):
    logout(request)
    messages.success(request, "Has cerrado sesión correctamente.")
    return redirect("inicio")

def normalizar_texto(texto):
    texto = unicodedata.normalize("NFD", texto.casefold())
    texto = "".join(
        caracter for caracter in texto
        if unicodedata.category(caracter) != "Mn"
    )
    return re.sub(r"\s+", " ", texto).strip()

def extraer_concentraciones(texto):
    return re.findall(
        r"(?<!\w)\d+(?:[.,]\d+)?\s*(?:mg|mcg|µg|ug|ml|g|%)\b",
        texto.casefold()
    )

@require_http_methods(["GET", "POST"])
def leer_receta(request):
    if not request.user.is_authenticated:
        return redirect("premium")

    if not hasattr(request.user, "suscripcion") or not request.user.suscripcion.es_premium:
        return redirect("premium")

    contexto = {
        "resultados": [],
        "texto_reconocido": "",
        "error": "",
        "farmacias_mapa": [],
    }
    
    if request.method == "GET":
        return render(request, "leer_receta.html", contexto)
    
    archivo = request.FILES.get("receta")
    
    if not archivo:
        contexto["error"] = "Selecciona una imagen de la receta."
        return render(request, "leer_receta.html", contexto)
    
    if archivo.size > 10 * 1024 * 1024: 
        contexto["error"] = "La imagen no puede superar los 10 MB."
        return render(request, "leer_receta.html", contexto)
    
    if not archivo.content_type.startswith("image/"):
        contexto["error"] = "El archivo debe ser imagen."
        return render(request, "leer_receta.html", contexto)

    #para que lea las imagenes
    try:
        archivo.seek(0)
        imagen = Image.open(archivo)
        imagen.verify()

        archivo.seek(0)
        imagen = Image.open(archivo).convert("RGB")
        
        #aumenta el tamaño para que no le cueste
        ancho, alto = imagen.size
        imagen = imagen.resize((ancho * 2, alto * 2))
        
        #convierte la escala a grises y la mejora
        imagen = ImageOps.grayscale(imagen)
        imagen = ImageOps.autocontrast(imagen)
        
        #elimina irregularidades (no se bien a que se refiere)
        imagen = imagen.filter(ImageFilter.SHARPEN)
        
        #convierte a blanco y negro
       # imagen = imagen.point(
       #     lambda pixel: 255 if pixel > 160 else 0
        #)

        if getattr(settings, "TESSERACT_CMD", None):
            pytesseract.pytesseract.tesseract_cmd = (
                settings.TESSERACT_CMD
            )

        texto = pytesseract.image_to_string(imagen, lang="spa", config="--psm 6")

        #separa el texto reconocido en lineas  
        lineas_receta = [
            normalizar_texto(linea)
            for linea in texto.splitlines()
            if linea.strip()
        ]       
        contexto["texto_reconocido"] = texto

    except pytesseract.TesseractNotFoundError:
        contexto["error"] = (
            "No se encontró Tesseract. Revisa su instalación y configuración."
        )
        return render(request, "leer_receta.html", contexto)

    except (UnidentifiedImageError, OSError, ValueError) as e:
        print(f"Error al abrir la receta: {e!r}")
        contexto["error"] = (
            "No se puede abrir la imagen. Prueba con otra."
        )
        return render(request, "leer_receta.html", contexto)

    except pytesseract.TesseractError:
        contexto["error"] = (
            "No se pudo reconocer el texto. Intenta con una imagen más clara."
        )
        return render(request, "leer_receta.html", contexto)
    
    texto_normalizado = normalizar_texto(texto)
    
    if not texto_normalizado:
        contexto["error"] = (
            "No se reconoció texto. Prueba con una imagen más nítida."
        )
        return render(request, "leer_receta.html", contexto)
    
    medicamentos = list(
        Medicamento.objects.prefetch_related(
            "productos__precios__farmacia"
        ).all()
    )

    indice_medicamentos = []

    for medicamento in medicamentos:

        nombre = normalizar_texto(medicamento.nombre)

        principio = normalizar_texto(
            medicamento.principio_activo or ""
        )

        productos = [
            normalizar_texto(producto.nombre)
            for producto in medicamento.productos.all()
        ]

        nombres = [nombre, principio] + productos

        palabras_clave = {
            n.split()[0]
            for n in nombres
            if n
        }

        indice_medicamentos.append({
            "medicamento": medicamento,
            "nombre": nombre,
            "principio": principio,
            "productos": productos,
            "nombres": nombres,
            "palabras_clave": palabras_clave,
        })

    candidatos = {}

    print("OCR NORMALIZADO:", repr(texto_normalizado))
    

    # Buscar coincidencias por nombre comercial o producto.
    for item in indice_medicamentos:

        medicamento = item["medicamento"]
        
        # Buscar el nombre completo del medicamento
        nombre_encontrado = (
            bool(item["nombre"])
            and item["nombre"] in texto_normalizado
        )

         # Buscar nombres completos de productos asociados
        producto_encontrado = any(
            nombre_producto
            and nombre_producto in texto_normalizado
            for nombre_producto in item["productos"]
        )
        

        if nombre_encontrado or producto_encontrado:

            candidatos[medicamento.id] = {
                "medicamento": medicamento,
                "tipo": "Nombre reconocido",
                "confirmacion": False,
            }



    #adjunta el precio 
    
    for candidato in candidatos.values():
        medicamento = candidato["medicamento"]

        precios = [
            precio
            for producto in medicamento.productos.all()
            for precio in producto.precios.all()
        ]

        candidato["precios"] = sorted(
            precios,
            key=lambda p: p.precio
        )

    print("TEXTO OCR:", texto)
    print("CANDIDATOS:", [
        c["medicamento"].nombre
        for c in candidatos.values()
    ])

    # Mostrar medicamentos no encontrados.
    no_encontrados = []

    for linea in lineas_receta:

        concentraciones_linea = extraer_concentraciones(linea)

        if not concentraciones_linea:
            continue

        coincidencia = False
        palabras_linea = set(linea.split())

        for item in indice_medicamentos:

            nombre_en_linea = bool(
                item["palabras_clave"] & palabras_linea
            )

            concentracion_en_catalogo = any(
                concentracion in nombre
                for nombre in item["nombres"]
                for concentracion in concentraciones_linea
            )

            if nombre_en_linea and concentracion_en_catalogo:
                coincidencia = True
                break

        if not coincidencia and linea not in no_encontrados:
            no_encontrados.append(linea)

    contexto["no_encontrados"] = no_encontrados

    contexto["resultados"] = list(candidatos.values())

    

    # Preparar las farmacias para el mapa de la receta.
    productos_por_farmacia = {}

    for resultado in contexto["resultados"]:
        medicamento = resultado["medicamento"]

        for precio in resultado["precios"]:
            farmacia_id = precio.farmacia_id

            if farmacia_id not in productos_por_farmacia:
                productos_por_farmacia[farmacia_id] = []

            productos_por_farmacia[farmacia_id].append({
                "medicamento": medicamento.nombre,
                "producto": precio.producto.nombre,
                "precio": str(precio.precio),
                "disponible": precio.disponible,
                "url_producto": precio.url_producto,
            })

    # Obtener las sucursales aprobadas de esas cadenas.
    farmacias_ids = list(productos_por_farmacia.keys())

    sucursales = Sucursal.objects.filter(
        farmacia_id__in=farmacias_ids,
        aprobada=True,
        latitud__isnull=False,
        longitud__isnull=False
    ).select_related("farmacia")

    farmacias_mapa = {}

    for sucursal in sucursales:
        farmacia = sucursal.farmacia

        farmacias_mapa[sucursal.id] = {
            "id": sucursal.id,
            "nombre": farmacia.nombre,
            "sucursal": sucursal.nombre,
            "cadena": farmacia.nombre,
            "direccion": sucursal.direccion,
            "latitud": float(sucursal.latitud),
            "longitud": float(sucursal.longitud),
            "productos": productos_por_farmacia.get(
                farmacia.id, []
            ),
        }
    contexto["farmacias_mapa"] = list(farmacias_mapa.values())
    
    print("OCR FINALIZADO")
    print("MEDICAMENTOS CARGADOS:", len(medicamentos))
    print("INDICE PREPARADO:", len(indice_medicamentos))
    print("CANDIDATOS:", len(candidatos))
    print("NO ENCONTRADOS:", len(no_encontrados))
    print("FARMACIAS MAPA:", len(contexto["farmacias_mapa"]))

    return render(request, "leer_receta.html", contexto)

#lista de producto (no es un carrito)
@require_POST
def agregar_a_lista(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    lista = request.session.get("lista_medicamentos", {})
    
    producto_id = str(producto.id)
    
    cantidad_actual = lista.get(producto_id, 0)
    lista[producto_id] = cantidad_actual + 1
    
    request.session["lista_medicamentos"] = lista
    
    mensaje = f"{producto.nombre} se agregó a tu lista"
    
    #si viene de javascript devuelve un json (who's json?)
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return JsonResponse({
            "ok": True,
            "mensaje": mensaje,
            "cantidad": lista[producto_id]
        })
    
    messages.success(request, mensaje)
    return redirect(request.META.get("HTTP_REFERER", "inicio"))

#agregar o quitar productos
@require_POST
def modificar_cantidad_lista(request, producto_id):
    lista = request.session.get("lista_medicamentos", {})
    producto_id = str(producto_id)
    
    accion = request.POST.get("accion")
    eliminado = False
    
    if producto_id in lista:
        if accion == "aumentar":
            lista[producto_id] += 1
        
        elif accion == "disminuir":
            lista[producto_id] -= 1
            
            if lista[producto_id] <= 0:
                del lista[producto_id]
    request.session["lista_medicamentos"] = lista
    return JsonResponse({
        "cantidad": lista.get(producto_id, 0),
        "eliminado": eliminado,
    })
    
#borrar la lista
@require_POST
def eliminar_de_lista(request, producto_id):
    lista = request.session.get("lista_medicamentos", {})
    producto_id = str(producto_id)
    
    lista.pop(producto_id, None)
    request.session["lista_medicamentos"] = lista
    return JsonResponse({"eliminado": True,})

#para ver la lista... por eso se llama ver_lista...
def ver_lista(request):
    lista = request.session.get("lista_medicamentos", {})
    
    productos = Producto.objects.filter(
        id__in=lista.keys()
    ).prefetch_related(
        Prefetch(
            "precios",
            queryset=Precio.objects.select_related(
                "farmacia"
            ).order_by("precio")
        )
    )
    
    items = []
    
    for producto in productos:
        cantidad = lista.get(str(producto.id), 1)
        precios_disponibles = [
            precio for precio in producto.precios.all()
            if precio.disponible
        ]
        
        items.append({
            "producto": producto,
            "cantidad": lista.get(str(producto.id), 1),
            "precios_disponibles": precios_disponibles,
        })
    
    comparacion_farmacias = []
    
    farmacias = Farmacia.objects.all().order_by("nombre")
    
    for farmacia in farmacias:
        total = 0
        productos_faltantes = []
        
        for item in items:
            precio_farmacia = next(
                (
                    precio for precio in item["precios_disponibles"] 
                    if precio.farmacia_id == farmacia.id
                ), 
                None
            )

            if precio_farmacia:
                total += precio_farmacia.precio * item["cantidad"]
            else:
                productos_faltantes.append(
                    item["producto"].nombre
                )
        
        comparacion_farmacias.append({
            "farmacia": farmacia,
            "total": total,
            "productos_faltantes": productos_faltantes,
            "completa": len(productos_faltantes) == 0,
        })
        
    #selecciona el menor precio por producto
    total_menor_precio = 0
    productos_menor_precio = []
    productos_sin_precio = []
    
    for item in items:
        if item["precios_disponibles"]:
            mejor_precio = min(
                item["precios_disponibles"],
                key=lambda precio: precio.precio
            )
            
            subtotal = mejor_precio.precio * item["cantidad"]
            total_menor_precio += subtotal
            
            productos_menor_precio.append({
                "producto": item["producto"],
                "cantidad": item["cantidad"],
                "farmacia": mejor_precio.farmacia,
                "precio_unitario": mejor_precio.precio,
                "subtotal": subtotal
            })
        else:
            productos_sin_precio.append(item["producto"].nombre)
            
        
    return render(request, "lista_medicamentos.html", 
                  {
                      "items": items,
                      "comparacion_farmacias": comparacion_farmacias,
                      "total_menor_precio": total_menor_precio,
                      "productos_menor_precio": productos_menor_precio,
                      "productos_sin_precio": productos_sin_precio
                      })

@require_GET
def planificar_ruta(request):
    
    print("GET recibido:", request.GET)
    print("Latitud recibida:", request.GET.get("lat"))
    print("Longitud recibida:", request.GET.get("lon"))

    lista = request.session.get("lista_medicamentos", {})
    
    if not lista:
        return JsonResponse({
            "error": "Tu lista de productos esta vacía."
        }, status=400)
    
    #obtener coord del usuario
    lat_usuario = request.GET.get("lat")
    lon_usuario = request.GET.get("lon")

    if not lat_usuario or not lon_usuario:
        return JsonResponse({
            "error": "No se recibió la ubicación del usuario."
        }, status=400)

    try:
        lat_usuario = float(lat_usuario)
        lon_usuario = float(lon_usuario)
    except (TypeError, ValueError):
        return JsonResponse({
            "error": "Las coordenadas del usuario no son válidas."
        }, status=400)

    productos = Producto.objects.filter(
        id__in=lista.keys()
    ).prefetch_related(
        Prefetch(
            "precios",
            queryset=Precio.objects.filter().select_related("farmacia")
        )
    )
    
    #obtener farmacia que tienen precios
    farmacias_obj = {}

    for producto in productos:
        for precio in producto.precios.all():
            if precio.farmacia:
                farmacias_obj[precio.farmacia_id] = precio.farmacia
    
    #buscar sucursales aprobadas de esa farmacias
    sucursales = Sucursal.objects.filter(
        farmacia_id__in=farmacias_obj.keys(),
        aprobada=True,
        latitud__isnull=False,
        longitud__isnull=False,
    )

    #calcular distancia entre dos coords
    def calcular_distancia(lat1, lon1, lat2, lon2):
        radio_tierra = 6371

        lat1, lon1, lat2, lon2 = map(
            radians,
            [lat1, lon1, lat2, lon2]
        )

        diferencia_lat = lat2 - lat1
        diferencia_lon = lon2 - lon1

        a = (
            sin(diferencia_lat / 2) ** 2
            + cos(lat1) * cos(lat2)
            * sin(diferencia_lon / 2) ** 2
        )

        c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return radio_tierra * c
    
    #Seleccionar la sucursal más cercana de cada farmacia
    farmacias = {}

    for farmacia_id, farmacia in farmacias_obj.items():

        sucursales_farmacia = [
            sucursal for sucursal in sucursales
            if sucursal.farmacia_id == farmacia_id
        ]

        if sucursales_farmacia:
            sucursal_cercana = min(
                sucursales_farmacia,
                key=lambda s: calcular_distancia(
                    lat_usuario,
                    lon_usuario,
                    float(s.latitud),
                    float(s.longitud)
                )
            )

            farmacias[farmacia_id] = {
                "id": farmacia.id,
                "nombre": sucursal_cercana.nombre,
                "nombre_sucursal": farmacia.nombre,
                "cadena": farmacia.nombre,
                "sucursal_id": sucursal_cercana.id,
                "direccion": sucursal_cercana.direccion,
                "comuna": sucursal_cercana.comuna,
                "latitud": float(sucursal_cercana.latitud),
                "longitud": float(sucursal_cercana.longitud)
            }
        #por si la farmacia no tiene sucursal registrada (no deberia pasar pero uno nunca sabe xd)
        elif farmacia.latitud is not None and farmacia.longitud is not None:
            farmacias[farmacia_id] = {
                "id": farmacia.id,
                "nombre": farmacia.nombre,
                "nombre_sucursal": farmacia.nombre,
                "cadena": farmacia.nombre,
                "sucursal_id": None,
                "direccion": farmacia.direccion,
                "comuna": "",
                "latitud": float(farmacia.latitud),
                "longitud": float(farmacia.longitud)
            }

    resultado = []

    
    for producto in productos:
        cantidad = lista.get(str(producto.id), 1)
        precios = []
        
        for precio in producto.precios.all():
            farmacia = precio.farmacia
            
            if not farmacia or farmacia.id not in farmacias:
                continue

            datos_farmacia = farmacias[farmacia.id]
            
            datos_precio = {
                "farmacia_id": farmacia.id,
                "farmacia": farmacia.nombre,
                "sucursal": datos_farmacia["nombre_sucursal"],
                "precio": float(precio.precio),
                "disponible": precio.disponible,
                "latitud": datos_farmacia["latitud"],
                "longitud": datos_farmacia["longitud"]
            }
            
            precios.append(datos_precio)
            

        resultado.append({
            "producto_id": producto.id,
            "nombre": producto.nombre,
            "cantidad": cantidad,
            "precios": precios
        })
        
    # DEBUG: revisar cobertura de productos
    print("\n========== DEBUG COBERTURA DE PRODUCTOS ==========")

    for producto in resultado:
        print(f"\nProducto: {producto['nombre']}")
        print(f"ID: {producto['producto_id']}")
        print(f"Cantidad de precios válidos: {len(producto['precios'])}")

        for precio in producto["precios"]:
            print(
                f"  - {precio['farmacia']}: "
                f"${precio['precio']}"
            )

        if not producto["precios"]:
            print("  !!! PRODUCTO SIN PRECIOS VÁLIDOS !!!")

    print("\nFarmacias disponibles para planificar:")
    for farmacia_id, farmacia in farmacias.items():
        print(f"  - {farmacia_id}: {farmacia['cadena']}")

    print("=================================================\n")
    
    #evalua TODAS las combinaciones de farmacias
    ids_farmacias = list(farmacias.keys())
    alternativas = []
    
    for cantidad_farmacias in range(1, len(ids_farmacias) + 1):
        for combinacion in combinations(
            ids_farmacias, cantidad_farmacias
        ):
            compras = {}
            total = 0
            combinacion_valida = True
            precios_sin_confirmar = 0
        
            for producto in resultado:
                opciones = [
                    precio for precio in producto["precios"]
                    if precio["farmacia_id"] in combinacion
                ]
                
                if not opciones:
                    combinacion_valida = False
                    break
                
                mejor_precio = min(
                    opciones,
                    key=lambda x: (
                        not x["disponible"],
                        x["precio"]
                    )
                )
                
                if not mejor_precio["disponible"]:
                    precios_sin_confirmar += 1
                
                subtotal = mejor_precio["precio"] * producto["cantidad"]
                total += subtotal
                
                farmacia_id = mejor_precio["farmacia_id"]
                
                if farmacia_id not in compras:
                    compras[farmacia_id] = {
                        "farmacia": farmacias[farmacia_id],
                        "productos": [],
                        "subtotal": 0
                    }
                    
                compras[farmacia_id]["productos"].append({
                    "producto": producto["nombre"],
                    "cantidad": producto["cantidad"],
                    "precio_unitario": mejor_precio["precio"],
                    "subtotal": subtotal,
                    "disponible": mejor_precio["disponible"]
                })
                
                compras[farmacia_id]["subtotal"] += subtotal
                
            if combinacion_valida:
                alternativas.append({
                    "total": total,
                    "compras": list(compras.values()),
                    "cantidad_farmacias": len(compras),
                    "precios_sin_confirmar": precios_sin_confirmar
                })
                
    if not alternativas:
        return JsonResponse({
            "error": "No hay suficientes precios disponibles para cubrir todos los productos."
        }, status=400)
    
    #buscar la alternativa más económica de una sola farmacia
    alternativas.sort(
        key=lambda x: (x["precios_sin_confirmar"], x["total"], x["cantidad_farmacias"])
    )
    
    mejor_general = alternativas[0]
    
    alternativas_una = [
        x for x in alternativas
        if x["cantidad_farmacias"] == 1
    ]
    
    alternativas_varias = [
        x for x in alternativas
        if x["cantidad_farmacias"] > 1
    ]
    
    mejor_una = alternativas_una[0] if alternativas_una else None
    mejor_dividida = alternativas_varias[0] if alternativas_varias else None
    
    #aplicar umbral de ahorro de 10% (si el ahorro es menos de 10 entonces ñao ñao)
    if mejor_una and mejor_dividida:
        ahorro = (
            (mejor_una["total"] - mejor_dividida["total"])
            / mejor_una["total"]
        ) * 100
        
        if ahorro >= 10:
            recomendacion = mejor_dividida
            criterio = "dividir_compra"
        else: 
            recomendacion = mejor_una
            criterio = "una_farmacia"
        
    elif mejor_una:
        ahorro = 0
        recomendacion = mejor_una
        criterio = "una_farmacia"
    
    else:
        ahorro = 0
        recomendacion = mejor_general
        criterio = "varias_farmacias_necesarias"
    
    return JsonResponse({
        "productos": resultado,
        "recomendacion": {
            "criterio": criterio,
            "total": round(recomendacion["total"], 2),
            "ahorro_porcentual": round(ahorro, 2),
            "cantidad_farmacias": recomendacion["cantidad_farmacias"],
            "compras": recomendacion["compras"]
        },
        "alternativas": {
            "una_farmacia": mejor_una,
            "varias_farmacias": mejor_dividida
        },
        "precios_sin_disponibilidad_confirmada": [
            {
                "producto": producto["nombre"],
                "farmacia": precio["farmacia"],
                "precio": precio["precio"]
            }
            for producto in resultado
            for precio in producto["precios"]
            if not precio["disponible"]
        ],
    })

@login_required(login_url='login')
def mi_cuenta(request):
    return render(request, 'mi_cuenta.html', {
        "ocultar_notificaciones_globales": True
    })

@login_required(login_url='login')
@require_http_methods(["GET", "POST"])
def editar_cuenta(request):

    if request.method == "POST":
        nombre = request.POST.get("nombre", "").strip()
        apellido = request.POST.get("apellido", "").strip()

        password_actual = request.POST.get("password_actual", "")
        nueva_password = request.POST.get("nueva_password", "")
        confirmar_password = request.POST.get("confirmar_password", "")

        if not nombre:
            messages.error(request, "El nombre no puede estar vacío.")

        else:
            quiere_cambiar_password = any([
                password_actual,
                nueva_password,
                confirmar_password
            ])

            if quiere_cambiar_password:

                if not all([
                    password_actual,
                    nueva_password,
                    confirmar_password
                ]):
                    messages.error(
                        request,
                        "Debes completar los tres campos de contraseña."
                    )

                elif not request.user.check_password(password_actual):
                    messages.error(
                        request,
                        "La contraseña actual es incorrecta."
                    )

                elif nueva_password != confirmar_password:
                    messages.error(
                        request,
                        "Las nuevas contraseñas no coinciden."
                    )

                else:
                    try:
                        validate_password(nueva_password, user=request.user)

                        request.user.set_password(nueva_password)
                        request.user.save()

                        update_session_auth_hash(request, request.user)

                    except ValidationError as errores:
                        for error in errores:
                            messages.error(request, error)

            if not messages.get_messages(request):
                request.user.first_name = nombre
                request.user.last_name = apellido
                request.user.save()

                if quiere_cambiar_password:
                    messages.success(
                        request,
                        "¡Tus datos y contraseña se actualizaron correctamente!"
                    )
                else:
                    messages.success(
                        request,
                        "¡Tus datos se actualizaron correctamente!"
                    )

                return redirect(request.path)

    return render(request, 'editar_cuenta.html', {
        "ocultar_notificaciones_globales": True
    })

def vista_premium(request):
    return render(request, "premium.html")


@require_GET
def imagen_medicamento(request, medicamento_id):
    imagen = get_object_or_404(
        ImagenProducto.objects.only("imagen", "formato"),
        medicamento_id=medicamento_id
    )

    formatos = {
        "WEBP": "image/webp",
        "JPEG": "image/jpeg",
        "PNG": "image/png",
    }

    response = HttpResponse(
        bytes(imagen.imagen),
        content_type=formatos.get(
            imagen.formato.upper(),
            "application/octet-stream"
        )
    )

    response["Cache-Control"] = "public, max-age=3600"
    return response


@require_GET
def imagen_producto(request, producto_id):
    imagen = get_object_or_404(
        ImagenProducto.objects.only("imagen", "formato"),
        producto_id=producto_id
    )

    formatos = {
        "WEBP": "image/webp",
        "JPEG": "image/jpeg",
        "PNG": "image/png",
    }

    response = HttpResponse(
        bytes(imagen.imagen),
        content_type=formatos.get(
            imagen.formato.upper(),
            "application/octet-stream"
        )
    )

    response["Cache-Control"] = "public, max-age=3600"
    return response

def normalizar_nombre_producto(nombre):
    texto = unicodedata.normalize(
        "NFKD", nombre or ""
    ).encode("ascii", "ignore").decode("ascii")
    
    texto = texto.lower()
    
    #corregir variaciones de escritura
    texto = re.sub(r"\bgm\b", "mg", texto)

    #eliminar separadores que no cambian la presentacion
    texto = re.sub(r"\bx\b", " ", texto)
    texto = re.sub(r"[^a-z0-9]+", " ", texto)
    
    return " ".join(texto.split())