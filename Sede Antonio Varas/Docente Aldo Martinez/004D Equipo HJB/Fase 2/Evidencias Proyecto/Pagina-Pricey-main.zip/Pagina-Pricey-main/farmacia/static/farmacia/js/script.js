
document.addEventListener("DOMContentLoaded", function () {

    const mensajeUbicacion = document.getElementById("mensaje-ubicacion");
    const contenedorMapa = document.getElementById("mapa-farmacias");

    let mapa = null;
    let marcadorUsuario = null;
    let marcadoresFarmacias = [];
    let grupoMarcadores = null;

    let ubicacionUsuario = null;
    let controlRuta = null;

    const botonPlanificar = document.getElementById(
        "btn-planificar-ruta"
    );

    if (botonPlanificar) {
        botonPlanificar.addEventListener("click", function () {
            planificarRutaCompras();
        });
    }
    
    // Recuperar la ubicación guardada durante esta sesión.
    try {
        const ubicacionGuardada = sessionStorage.getItem("ubicacionUsuario");

        if (ubicacionGuardada) {
            const ubicacion = JSON.parse(ubicacionGuardada);
            const latitud = Number(ubicacion.lat);
            const longitud = Number(ubicacion.lng);

            if (
                Number.isFinite(latitud) &&
                Number.isFinite(longitud) &&
                latitud >= -90 && latitud <= 90 &&
                longitud >= -180 && longitud <= 180
            ) {
                ubicacionUsuario = {
                    latitud: latitud,
                    longitud: longitud
                };
            }
        }
    } catch (error) {
        console.warn("No se pudo recuperar la ubicación guardada.", error);
    }


    
function calcularDistanciaKm(lat1, lon1, lat2, lon2) {
    const radioTierra = 6371;
    const radianes = grados => grados * Math.PI / 180;

    const diferenciaLatitud = radianes(lat2 - lat1);
    const diferenciaLongitud = radianes(lon2 - lon1);

    const a =
        Math.sin(diferenciaLatitud / 2) ** 2 +
        Math.cos(radianes(lat1)) *
        Math.cos(radianes(lat2)) *
        Math.sin(diferenciaLongitud / 2) ** 2;

    const c = 2 * Math.atan2(
        Math.sqrt(a),
        Math.sqrt(1 - a)
    );

    return radioTierra * c;
}

async function planificarRutaCompras() {
    if (!ubicacionUsuario) {
        mensajeUbicacion.textContent =
            "Primero debes obtener tu ubicación para planificar la ruta.";
        return;
    }

    if (!mapa) {
        mensajeUbicacion.textContent =
            "El mapa todavía no está disponible.";
        return;
    }

    if (
        typeof L.Routing === "undefined" ||
        typeof L.Routing.control !== "function"
    ) {
        mensajeUbicacion.textContent =
            "No se pudo cargar el complemento de rutas.";
        return;
    }

    mensajeUbicacion.textContent=
        "Calculando la mejor ruta para tus compras...";
    
    console.log("Ubicación del usuario:", ubicacionUsuario);





    try {
        const parametros = new URLSearchParams({
            lat: ubicacionUsuario.latitud,
            lon: ubicacionUsuario.longitud
        })

        const respuesta = await fetch(`/mi-lista/planificar-ruta/?${parametros.toString()}`);
        const datos = await respuesta.json();
        console.log("Respuesta del endpoint:", datos);
        console.log(
            "Detalle completo:",
            JSON.stringify(datos, null, 2)
        );

        if (!respuesta.ok) {
            throw new Error(
                datos.error || "No se pudo obtener la planificación."
            );
        }

        const compras = datos.recomendacion.compras || [];
        console.log(
            "Farmacias recomendadas por Django:",
            compras.map(compra => compra.farmacia)
        );

        const productosSinConfirmar = 
            datos.precios_sin_disponibilidad_confirmada || [];

        // Obtener las farmacias sin duplicados.
        const farmaciasUnicas = [
            ...new Map(
                compras.map(compra => [
                    compra.farmacia.id,
                    compra.farmacia
                ])
            ).values()
        ];

        if (farmaciasUnicas.length === 0) {
            mensajeUbicacion.textContent =
                "No hay farmacias disponibles para planificar la ruta.";
            return;
        }

        // Ordenar las paradas por cercanía desde la ubicación del usuario.
        const paradasOrdenadas = [];
        let puntoActual = {
            latitud: ubicacionUsuario.latitud,
            longitud: ubicacionUsuario.longitud
        };

        const pendientes = [...farmaciasUnicas];

        while (pendientes.length > 0) {
            pendientes.sort((a, b) => {
                const distanciaA = calcularDistanciaKm(
                    puntoActual.latitud,
                    puntoActual.longitud,
                    a.latitud,
                    a.longitud
                );

                const distanciaB = calcularDistanciaKm(
                    puntoActual.latitud,
                    puntoActual.longitud,
                    b.latitud,
                    b.longitud
                );

                return distanciaA - distanciaB;
            });

            const siguiente = pendientes.shift();

            paradasOrdenadas.push(siguiente);

            puntoActual = {
                latitud: siguiente.latitud,
                longitud: siguiente.longitud
            };
        }

        console.log(
            "Paradas que se enviarán al mapa:",
            paradasOrdenadas
        );

        // Eliminar la ruta anterior.
        if (controlRuta) {
            mapa.removeControl(controlRuta);
            controlRuta = null;
        }

        // Crear los puntos de la ruta.
        const puntos = [
            L.latLng(
                ubicacionUsuario.latitud,
                ubicacionUsuario.longitud
            ),
            ...paradasOrdenadas.map(farmacia =>
                L.latLng(
                    farmacia.latitud,
                    farmacia.longitud
                )
            )
        ];

        mensajeUbicacion.textContent =
            "Calculando recorrido por " +
            paradasOrdenadas.length + " farmacia(s)...";

        const nuevaRuta = L.Routing.control({
            waypoints: puntos,

            router: L.Routing.osrmv1({
                serviceUrl:
                    "https://router.project-osrm.org/route/v1"
            }),

            addWaypoints: false,
            draggableWaypoints: false,
            fitSelectedRoutes: true,
            show: true,
            routeWhileDragging: false,
            language: "es",

            createMarker: function () {
                return null;
            }
        });

        controlRuta = nuevaRuta;

        controlRuta.on("routesfound", function (evento) {
            if (!evento.routes || evento.routes.length === 0) {
                mensajeUbicacion.textContent =
                    "No se encontró una ruta para tus compras.";
                return;
            }

            const ruta = evento.routes[0];

            const distanciaKm =
                ruta.summary.totalDistance / 1000;

            const duracionMinutos =
                Math.round(ruta.summary.totalTime / 60);

            const nombres = paradasOrdenadas
                .map((farmacia, indice) =>
                    (indice + 1) + ". " + farmacia.nombre
                )
                .join(" → ");
            
            const resumenRuta =
                "Ruta de compra: " + nombres +
                ". Distancia: " + distanciaKm.toFixed(2) +
                " km. Duración estimada: " +
                duracionMinutos + " minutos.";

            if (productosSinConfirmar.length > 0) {
                const detalle = productosSinConfirmar.map(producto =>
                    producto.producto + " (" + producto.farmacia + ")"
                ).join(", ");

                mensajeUbicacion.textContent =
                    resumenRuta +
                    " ⚠️ Atención: los siguientes productos tienen precios " +
                    "registrados, pero su disponibilidad no está confirmada: " +
                    detalle + ".";
            } else {    
                mensajeUbicacion.textContent =
                    resumenRuta +
                    " Todos los productos seleccionados tienen disponibilidad confirmada.";
            }
        });

        controlRuta.on("routingerror", function () {
            mensajeUbicacion.textContent =
                "No se pudo calcular la ruta. Inténtalo nuevamente.";
        });

        controlRuta.addTo(mapa);
    } catch (error) {
        console.error("Error al planificar la ruta:", error);

        mensajeUbicacion.textContent =
            error.message || "Ocurrió un error al planificar la ruta.";
    }

}

    // Mapa de farmacias que aparecen en la lectura de recetas.
    const contenedorMapaReceta = document.getElementById("mapa-receta");

    if (contenedorMapaReceta && typeof L !== "undefined") {
        const elementoDatos = document.getElementById("farmacias-receta-data");
        const mensajeMapa = document.getElementById("mensaje-mapa-receta");

        let farmaciasReceta = [];

        if (elementoDatos) {
            try {
                farmaciasReceta = JSON.parse(elementoDatos.textContent);
            } catch (error) {
                console.error(
                    "No se pudieron leer los datos de las farmacias.",
                    error
                );
            }
        }

        const mapaReceta = L.map("mapa-receta");

        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19
        }).addTo(mapaReceta);

        // Colores de las cadenas de farmacias.
        const COLORES_FARMACIAS_RECETA = {
            "cruz verde": "#16A34A",
            "dr simi": "#2563EB",
            "farmacias ahumada": "#E87924",
            "salcobrand": "#9333EA"
        };

        function normalizarCadenaReceta(cadena) {
            return (cadena || "")
                .trim()
                .toLowerCase()
                .replace(/[.]/g, "")
                .replace(/\s+/g, " ");
        }

        function obtenerColorFarmaciaReceta(farmacia) {
            const cadena = normalizarCadenaReceta(
                farmacia.cadena || farmacia.farmacia || farmacia.nombre
            );

            return COLORES_FARMACIAS_RECETA[cadena] || "#64748B";
        }

        const puntosReceta = [];

        // Grupo de marcadores con clústeres.
        const grupoFarmaciasReceta = L.markerClusterGroup({
            showCoverageOnHover: false,
            maxClusterRadius: 50,
            spiderfyOnMaxZoom: true,
            zoomToBoundsOnClick: true
        });

        farmaciasReceta.forEach(function (farmacia) {
            const latitud = Number(farmacia.latitud);
            const longitud = Number(farmacia.longitud);

            if (
                !Number.isFinite(latitud) ||
                !Number.isFinite(longitud) ||
                latitud < -90 || latitud > 90 ||
                longitud < -180 || longitud > 180
            ) {
                return;
            }

            const color = obtenerColorFarmaciaReceta(farmacia);

            // Crear marcador personalizado según la cadena.
            const iconoFarmacia = L.divIcon({
                className: "marcador-farmacia",
                html: `
                    <div class="marcador-farmacia-circulo"
                        style="background-color: ${color};">
                    </div>
                `,
                iconSize: [18, 18],
                iconAnchor: [9, 9],
                popupAnchor: [0, -10]
            });

            const marcador = L.marker(
                [latitud, longitud],
                { icon: iconoFarmacia }
            );

            // Preparar información del popup.
            const contenido = document.createElement("div");

            const nombre = document.createElement("strong");
            nombre.textContent =
                farmacia.sucursal || farmacia.nombre || "Farmacia";
            contenido.appendChild(nombre);

            const cadena = document.createElement("p");
            cadena.textContent =
                farmacia.cadena || farmacia.farmacia || farmacia.nombre;
            contenido.appendChild(cadena);

            const direccion = document.createElement("p");
            direccion.textContent =
                farmacia.direccion || "Dirección no disponible";
            contenido.appendChild(direccion);

            (farmacia.productos || []).forEach(function (producto) {
                const detalle = document.createElement("p");
                const precio = Number(producto.precio);

                detalle.textContent =
                    (producto.producto || producto.medicamento) + ": " +
                    (Number.isFinite(precio)
                        ? precio.toLocaleString("es-CL", {
                            style: "currency",
                            currency: "CLP",
                            maximumFractionDigits: 0
                        })
                        : "Precio no disponible");

                contenido.appendChild(detalle);
            });

            marcador.bindPopup(contenido);

            grupoFarmaciasReceta.addLayer(marcador);
            puntosReceta.push([latitud, longitud]);
        });

        // Agregar marcadores al mapa.
        mapaReceta.addLayer(grupoFarmaciasReceta);

        // Mostrar ubicación guardada del usuario, si existe.
        try {
            const guardada = sessionStorage.getItem("ubicacionUsuario");

            if (guardada) {
                const ubicacion = JSON.parse(guardada);
                const latitud = Number(ubicacion.lat);
                const longitud = Number(ubicacion.lng);

                if (
                    Number.isFinite(latitud) &&
                    Number.isFinite(longitud) &&
                    latitud >= -90 && latitud <= 90 &&
                    longitud >= -180 && longitud <= 180
                ) {
                    L.circleMarker([latitud, longitud], {
                        radius: 8,
                        color: "#2563eb",
                        fillColor: "#3b82f6",
                        fillOpacity: 1
                    })
                    .addTo(mapaReceta)
                    .bindPopup("Tu ubicación");

                    puntosReceta.push([latitud, longitud]);
                }
            }
        } catch (error) {
            console.warn(
                "No se pudo recuperar la ubicación guardada.",
                error
            );
        }

        // Ajustar el mapa a las ubicaciones disponibles.
        if (puntosReceta.length > 0) {
            mapaReceta.fitBounds(puntosReceta, {
                padding: [25, 25],
                maxZoom: 14
            });
        } else {
            mapaReceta.setView([-33.4489, -70.6693], 12);
        }

        if (mensajeMapa) {
            mensajeMapa.textContent = farmaciasReceta.length > 0
                ? "Selecciona un marcador para consultar los precios."
                : "No hay farmacias con coordenadas para los medicamentos reconocidos.";
        }

        console.log(
            "Sucursales mostradas en el mapa de recetas:",
            grupoFarmaciasReceta.getLayers().length
        );

        setTimeout(function () {
            mapaReceta.invalidateSize();
        }, 100);
    }

    if (!mensajeUbicacion) {
        console.error("No se encontró el mensaje de ubicación.");
        return;
    }

    const COLORES_FARMACIAS = {
        "cruz verde": "#16A34A",
        "dr simi": "#2563EB",
        "farmacias ahumada": "#E87924",
        "salcobrand": "#9333EA"
    };

    function obtenerColorFarmacia(farmacia) {
        const cadena = (farmacia.farmacia || "").trim().toLowerCase();
        return COLORES_FARMACIAS[cadena] || "#64748B";
    }

    let cadenasSeleccionadas = new Set([
        "cruz verde",
        "dr simi",
        "farmacias ahumada",
        "salcobrand"
    ]);

    function normalizarCadena(cadena) {
        return (cadena || "")
            .trim()
            .toLowerCase()
            .replace(/[.]/g, "")
            .replace(/\s+/g, " ");
    }

    function aplicarFiltrosFarmacias(){
        if (!grupoMarcadores) return;

        // Limpiar los marcadores visibles del mapa.
        grupoMarcadores.clearLayers();

        // Volver a agregar solamente los marcadores seleccionados.
        marcadoresFarmacias.forEach(function (marcador) {
            if (cadenasSeleccionadas.has(marcador.cadenaFarmacia)) {
                grupoMarcadores.addLayer(marcador);
            }
        });
    }

    function configurarFiltrosFarmacias() {
        const botones = document.querySelectorAll(".filtro-farmacia");

        botones.forEach(function (boton) {
            boton.addEventListener("click", function () {
                const cadena = boton.dataset.cadena;

                if (cadena === "todas") {
                    cadenasSeleccionadas = new Set([
                        "cruz verde",
                        "dr simi",
                        "farmacias ahumada",
                        "salcobrand"
                    ]);
                } else {
                    if (cadenasSeleccionadas.has(cadena)) {
                        cadenasSeleccionadas.delete(cadena);
                    } else {
                        cadenasSeleccionadas.add(cadena);
                    }
                }

                // Actualizar apariencia de los botones.
                botones.forEach(function (otroBoton) {
                    const otraCadena = otroBoton.dataset.cadena;

                    const activo = otraCadena === "todas"
                        ? cadenasSeleccionadas.size === 4
                        : cadenasSeleccionadas.has(otraCadena);

                    otroBoton.classList.toggle("activo", activo);
                    otroBoton.setAttribute("aria-pressed", String(activo));
                });

                aplicarFiltrosFarmacias();
            });
        });
    }
    // Cargar y ordenar las farmacias según la ubicación del usuario.
    async function cargarFarmacias() {
        try {
            const respuesta = await fetch("/api/farmacias/");

            if (!respuesta.ok) {
                throw new Error("No se pudieron obtener las farmacias.");
            }

            const datos = await respuesta.json();

            // Evitar duplicar marcadores si volvemos a cargar.
            grupoMarcadores.clearLayers();
            marcadoresFarmacias = [];

            const farmaciasOrdenadas = datos.farmacias
                .map(function (farmacia) {
                    const latitud = Number(farmacia.latitud);
                    const longitud = Number(farmacia.longitud);

                    if (
                        farmacia.latitud == null ||
                        farmacia.longitud == null ||
                        !Number.isFinite(latitud) ||
                        !Number.isFinite(longitud) ||
                        latitud < -90 || latitud > 90 ||
                        longitud < -180 || longitud > 180
                    ) {
                        return null;
                    }

                    const distancia = ubicacionUsuario
                        ? calcularDistanciaKm(
                            ubicacionUsuario.latitud,
                            ubicacionUsuario.longitud,
                            latitud,
                            longitud
                        )
                        : null;

                    return {
                        ...farmacia,
                        latitud: latitud,
                        longitud: longitud,
                        distancia: distancia
                    };
                })
                .filter(function (farmacia) {
                    return farmacia !== null;
                });

            // Si conocemos la ubicación, mostrar primero las más cercanas.
            if (ubicacionUsuario) {
                farmaciasOrdenadas.sort(function (a, b) {
                    return a.distancia - b.distancia;
                });
            }

            farmaciasOrdenadas.forEach(function (farmacia) {
                const color = obtenerColorFarmacia(farmacia);

                const iconoFarmacia = L.divIcon({
                    className: "marcador-farmacia",
                    html: `
                        <div class="marcador-farmacia-circulo"
                            style="background-color: ${color};">
                        </div>
                    `,
                    iconSize: [18, 18],
                    iconAnchor: [9, 9],
                    popupAnchor: [0, -10]
                });

                const marcador = L.marker(
                    [farmacia.latitud, farmacia.longitud],
                    { icon: iconoFarmacia }
                );
                marcador.cadenaFarmacia = normalizarCadena(farmacia.farmacia);

                const contenido = document.createElement("div");
                const nombre = document.createElement("strong");
                const direccion = document.createElement("p");

                nombre.textContent = farmacia.nombre;
                direccion.textContent =
                    farmacia.direccion || "Dirección no disponible";

                contenido.appendChild(nombre);
                contenido.appendChild(direccion);

                if (farmacia.distancia !== null) {
                    const distancia = document.createElement("p");
                    distancia.textContent =
                        "A " + farmacia.distancia.toFixed(2) + " km en línea recta";
                    contenido.appendChild(distancia);
                }
                

                // Botón para calcular la ruta hasta esta farmacia.
                const botonRuta = document.createElement("button");
                botonRuta.textContent = "Cómo llegar";
                botonRuta.type = "button";
                botonRuta.className = "btn-ruta";
                
                botonRuta.style.marginTop = "8px";
                botonRuta.style.padding = "7px 12px";
                botonRuta.style.border = "none";
                botonRuta.style.borderRadius = "6px";
                botonRuta.style.backgroundColor = "#0F766E";
                botonRuta.style.color = "#FFFFFF";
                botonRuta.style.cursor = "pointer";

                botonRuta.addEventListener("click", function () {
                    // Comprobar que el usuario haya compartido su ubicación.
                    if (!ubicacionUsuario) {
                        mensajeUbicacion.textContent =
                            "Primero debes obtener tu ubicación para calcular la ruta.";
                        return;
                    }

                    // Comprobar que Leaflet Routing Machine esté cargado.
                    if (
                        typeof L.Routing === "undefined" ||
                        typeof L.Routing.control !== "function"
                    ) {
                        mensajeUbicacion.textContent =
                            "No se pudo cargar el complemento de rutas. Revisa tu conexión.";
                        return;
                    }

                    // Eliminar la ruta anterior, si existe.
                    if (controlRuta) {
                        mapa.removeControl(controlRuta);
                        controlRuta = null;
                    }

                     mensajeUbicacion.textContent =
                        "Calculando ruta hacia " + farmacia.nombre + "...";

                    try {
                        // Crear el control sin agregarlo todavía al mapa.
                        const nuevoControlRuta = L.Routing.control({
                            waypoints: [
                                L.latLng(
                                    ubicacionUsuario.latitud,
                                    ubicacionUsuario.longitud
                                ),
                                L.latLng(
                                    farmacia.latitud,
                                    farmacia.longitud
                                )
                            ],

                            router: L.Routing.osrmv1({
                                serviceUrl: "https://router.project-osrm.org/route/v1"
                            }),

                            addWaypoints: false,
                            draggableWaypoints: false,
                            fitSelectedRoutes: true,
                            show: true,
                            routeWhileDragging: false,
                            language: "es",

                            // Evita crear marcadores adicionales para la ruta.
                            createMarker: function () {
                                return null;
                            }
                        });

                        // Guardar el control antes de agregarlo al mapa.
                        controlRuta = nuevoControlRuta;

                        // El resultado de la ruta.
                        controlRuta.on("routesfound", function (evento) {
                            if (
                                !evento.routes || evento.routes.length === 0
                            ) {
                                mensajeUbicacion.textContent =
                                    "No se encontró una ruta para esta farmacia.";
                                return;
                            }

                            const ruta = evento.routes[0];
                            const distanciaKm = ruta.summary.totalDistance / 1000;
                            const duracionMinutos = Math.round(ruta.summary.totalTime / 60);

                            mensajeUbicacion.textContent = 
                                "Ruta hacia " +
                                farmacia.nombre +
                                ": " +
                                distanciaKm.toFixed(2) +
                                " km. Duración estimada: " +
                                duracionMinutos +
                                " minutos.";
                    
                        });

                        // Gestionar errores del servicio de rutas.
                        controlRuta.on( "routingerror", function (){
                            mensajeUbicacion.textContent =
                                "No se pudo calcular la ruta. Inténtalo nuevamente.";
                        });

                        // Agregar el control al mapa después de registrar los eventos.
                        controlRuta.addTo(mapa);
                            
                    } catch (error) {
                        console.error("Error al calcular la ruta:", error);

                        mensajeUbicacion.textContent = 
                            "Ocurrió un error al intentar calcular la ruta.";
                    }

                });

                contenido.appendChild(botonRuta);
                marcador.bindPopup(contenido);
                grupoMarcadores.addLayer(marcador);
                marcadoresFarmacias.push(marcador);

            });

            console.log(
                "Farmacias cargadas:",
                marcadoresFarmacias.length
            );

            if (ubicacionUsuario && farmaciasOrdenadas.length > 0) {
                console.log(
                    "Farmacia más cercana:",
                    farmaciasOrdenadas[0].nombre,
                    farmaciasOrdenadas[0].distancia.toFixed(2) + " km"
                );
            }
        } catch (error) {
            console.error("Error al cargar las farmacias:", error);
            mensajeUbicacion.textContent =
                "No se pudieron cargar las farmacias. Inténtalo nuevamente.";
        }
    }




    // Crear el mapa inicial si Leaflet está disponible.
    if (contenedorMapa && typeof L !== "undefined") {
        mapa = L.map("mapa-farmacias").setView([-33.4489, -70.6693], 12);

        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(mapa);

        // Crear el grupo de marcadores después de inicializar el mapa.
        grupoMarcadores = L.markerClusterGroup({
            maxClusterRadius: 50,
            disableClusteringAtZoom: 17,
            spiderfyOnMaxZoom: true,
            showCoverageOnHover: false,
            zoomToBoundsOnClick: true,
            animate: true
        });
        
        // Agregar el grupo al mapa.
        mapa.addLayer(grupoMarcadores);
        
        configurarFiltrosFarmacias();

        obtenerUbicacion();
    } else if (contenedorMapa) {
        mensajeUbicacion.textContent =
            "No se pudo cargar el mapa. Revisa tu conexión a internet.";
    }

    function obtenerUbicacion() {

        //si ya tenemos la ubicacion la reutilizamos
        if (ubicacionUsuario) {

            mensajeUbicacion.textContent = 
                "Utilizando tu ubicación guardada durante esta sesión.";
            
            if (mapa) {
                const latitud = ubicacionUsuario.latitud;
                const longitud = ubicacionUsuario.longitud;

                mapa.setView([latitud, longitud], 15);

                if (marcadorUsuario) {
                    marcadorUsuario.setLatLng([latitud, longitud]);
                } else {
                    marcadorUsuario = L.marker([latitud, longitud]).addTo(mapa);
                }

                marcadorUsuario.bindPopup("¡Estás aquí :)!").openPopup();

                cargarFarmacias();
            }
            return
        }
        //comprobar compatibilidad con navegador

        if (!navigator.geolocation) {
            mensajeUbicacion.textContent = 
                "Tu navegador no admite geolocalización :(.";
            cargarFarmacias();
            return;
        }

        mensajeUbicacion.textContent =
            "Solicitando permiso para conocer tu ubicación...";
        
        //para pedir ubicación automatica
        navigator.geolocation.getCurrentPosition(
            
            function (posicion) {
                const latitud = posicion.coords.latitude;
                const longitud = posicion.coords.longitude;

                ubicacionUsuario = {
                    latitud: latitud,
                    longitud: longitud
                };

                //guarda la ubicación
                try{
                    sessionStorage.setItem(
                        "ubicacionUsuario",
                        JSON.stringify({
                            lat: latitud,
                            lng: longitud
                        })
                    );
                } catch (error) {
                    console.warn(
                        "No se pudo guardar la ubicación.",
                        error
                    );
                }

                mensajeUbicacion.textContent = 
                    "¡Ubicación obtenida correctamente :)!";

                mostrarNotificacion(
                    "¡Ubicación obtenida correctamente! Ahora podemos mostrarte las farmacias cercanas.",
                    "success"
                );
                
                if (mapa) {

                    mapa.setView([latitud, longitud], 15);

                    if (marcadorUsuario) {
                        marcadorUsuario.setLatLng([latitud, longitud]);
                    } else {
                        marcadorUsuario = L.marker([latitud, longitud]).addTo(mapa);
                    }

                    marcadorUsuario.bindPopup("¡Estás aquí :)!").openPopup();

                    cargarFarmacias();
                }

                console.log("Ubicación obtenida:", latitud, longitud);

            },

            function (error) {
                if (error.code === 1) {
                    mensajeUbicacion.textContent =
                        "No tenemos permiso para acceder a tu ubicación. Puedes habilitarlo desde tu navegador.";
                } else if (error.code === 2) {
                    mensajeUbicacion.textContent =
                        "No pudimos determinar tu ubicación. :(";
                } else if (error.code === 3) {
                    mensajeUbicacion.textContent =
                        "La solicitud tardó demasiado. Inténtalo nuevamente.";
                } else {
                    mensajeUbicacion.textContent =
                        "Ocurrió un error al obtener tu ubicación.";
                }
                //hay que mostrar las farmacias aunque no se tenga ubicación
                cargarFarmacias();
            },
            {
                enableHighAccuracy: true,
                timeout: 15000,
                maximumAge: 0
            }
        );

    }
});

document.addEventListener("submit", async function(event) {

    const formulario = event.target.closest(".form-agregar-lista");

    if (!formulario) return;

    event.preventDefault();

    const boton = formulario.querySelector("button[type='submit']");
    const mensaje = formulario.querySelector(".mensaje-agregar");

    const textoOriginal = boton.textContent;

    boton.disabled = true;
    boton.textContent = "Agregando...";

    try {
        const respuesta = await fetch(formulario.action, {
            method: "POST",
            body: new FormData(formulario),
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(datos.mensaje || "No se pudo agregar el producto.");
        }

        boton.textContent = "✓ Agregado";
        mostrarNotificacion(datos.mensaje, "success");

        setTimeout(() => {
            boton.textContent = textoOriginal;
            mensaje.textContent = "";
            boton.disabled = false;
        }, 1800);

    } catch (error) {
        console.error("Error al agregar producto:", error);

        boton.textContent = "Error al agregar";
        mensaje.textContent = "No se pudo agregar. Intenta nuevamente.";

        setTimeout(() => {
            boton.textContent = textoOriginal;
            boton.disabled = false;
            mensaje.textContent = "";
        }, 2000);
    }
});

// Paginación dinámica del catálogo
async function cargarCatalogo(url, actualizarHistorial = true) {

    const catalogoActual = document.querySelector("#catalogo");

    if (!catalogoActual) return;

    catalogoActual.setAttribute("aria-busy", "true");

    try {
        const respuesta = await fetch(url, {
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        if (!respuesta.ok) {
            throw new Error("No se pudo cargar el catálogo.");
        }

        const html = await respuesta.text();

        const documento = new DOMParser().parseFromString(
            html,
            "text/html"
        );

        const nuevoCatalogo = documento.querySelector("#catalogo");

        if (!nuevoCatalogo) {
            throw new Error("No se encontró el catálogo.");
        }

        catalogoActual.replaceWith(nuevoCatalogo);

        if (actualizarHistorial) {
            history.pushState({}, "", url);
        }

        actualizarFiltrosCategoria(url);

    } catch (error) {
        console.error("Error al cambiar de página:", error);
        window.location.href = url;

    }
}

// Interceptar los clics de filtros y paginación
document.addEventListener("click", function(event) {

    //detecta el filtro de categorias
    const filtro = event.target.closest(".filtros-categorias .boton-categoria");

    //detecta paginación
    const pagina = event.target.closest("#catalogo .paginacion a");

    //si no es ninguno de los dos no hace nada
    const enlace = filtro || pagina;

    if (!enlace) return;

    event.preventDefault();

    //carga el catalogo sin recargar la pagina
    cargarCatalogo(enlace.href);

});

//para actualizar el filtro
function actualizarFiltrosCategoria(url) {

    const parametros = new URL(url, window.location.origin).searchParams;
    const categoriaActual = parametros.get("categoria") || "";

    document.querySelectorAll(
        ".filtros-categorias .boton-categoria"
    ).forEach(boton => {

        const destino = new URL(boton.href, window.location.origin);
        const categoriaBoton = destino.searchParams.get("categoria") || "";

        boton.classList.toggle(
            "seleccionada", categoriaBoton == categoriaActual);
    });
}

// Permitir que atrás y adelante del navegador funcionen correctamente
window.addEventListener("popstate", function() {

    cargarCatalogo(window.location.href, false);

});


// NOTIFICACIONES TEMPORALES FARMA PRICEY



function iniciarNotificaciones() {
    const notificaciones = document.querySelectorAll(".notificacion");

    notificaciones.forEach(function (notificacion) {
        if (notificacion.dataset.iniciada) return;

        notificacion.dataset.iniciada = "true";

        function cerrar() {
            if (!notificacion.isConnected) return;

            notificacion.classList.add("ocultar");
            

            setTimeout(function () {
                notificacion.remove();
            }, 300);
        }

        const botonCerrar = notificacion.querySelector(".notificacion-cerrar");

        if (botonCerrar) {
            botonCerrar.addEventListener("click", cerrar);
        }

        setTimeout(cerrar, 3000);
    });
}

document.addEventListener("DOMContentLoaded", iniciarNotificaciones);



function mostrarNotificacion(texto, tipo = "success") {
    let contenedor = document.querySelector(".contenedor-notificaciones");

    if (!contenedor) {
        contenedor = document.createElement("div");
        contenedor.className = "contenedor-notificaciones";
        document.body.appendChild(contenedor);
    }

    const notificacion = document.createElement("div");
    notificacion.className = `notificacion ${tipo}`;

    const icono = document.createElement("span");
    icono.className = "notificacion-icono";
    icono.textContent = "✓";

    const mensaje = document.createElement("span");
    mensaje.className = "notificacion-texto";
    mensaje.textContent = texto;

    const cerrar = document.createElement("button");
    cerrar.className = "notificacion-cerrar";
    cerrar.type = "button";
    cerrar.textContent = "×";
    cerrar.setAttribute("aria-label", "Cerrar notificación");

    notificacion.append(icono, mensaje, cerrar);
    contenedor.appendChild(notificacion);

    let temporizador;

    function cerrarNotificacion() {
        clearTimeout(temporizador);
        notificacion.classList.add("ocultar");

        setTimeout(() => {
            notificacion.remove();

            if (contenedor.children.length === 0) {
                contenedor.remove();
            }
        }, 300);
    }

    cerrar.addEventListener("click", cerrarNotificacion);

    temporizador = setTimeout(cerrarNotificacion, 3000);
}
